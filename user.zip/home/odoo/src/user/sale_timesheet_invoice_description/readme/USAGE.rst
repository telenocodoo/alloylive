To use this module, you need to:

#. Go to *Sales -> Orders -> Orders* and create a new Sale Order.
#. Add line selecting a product with

   - *Product Type* -> **Service**
   - *Service Invoicing Policy* -> **Timesheets on tasks**
   - *Service Tracking* -> **Create a task in a new project**

   e.g. *Junior Architect (Invoice on Timesheets)*
#. Confirm Sale
#. Go to *Timesheets -> Timesheet -> My Timesheets* and create line with same
   project of SO and the related task
#. Go to the Sale Order and select *Other Information* -> **Timesheet invoice
   description**
#. *Create Invoice*
