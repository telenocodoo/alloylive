To configure this module, you need to:

#. Go to *Timesheets -> Configuration -> Settings -> Billing* and set
   Default Timesheet Invoice Description.
