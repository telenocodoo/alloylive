from . import test_generic_location
