==============
Project Team
==============

* This module is developed to set project team members.

* You can configure the project teams from 'Projects team' menu under configuration of projects.

* Once you select the relevant project team, you will get the associated team members automatically assigned to that project team.

Usage
=====

Bug Tracker
===========

Credits
=======

Contributors
------------

* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>

