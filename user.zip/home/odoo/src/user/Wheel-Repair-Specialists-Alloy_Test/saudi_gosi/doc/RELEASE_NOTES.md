## Module <saudi_gosi>

#### 18.09.2018
#### Version 12.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project


## Module <saudi_gosi>

#### 12.11.2018
#### Version 12.0.1.0.1
##### FIX
- Salary Structure Issue
